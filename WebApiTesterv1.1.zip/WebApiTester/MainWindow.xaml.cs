using System.Windows;

namespace WebApiTester;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
