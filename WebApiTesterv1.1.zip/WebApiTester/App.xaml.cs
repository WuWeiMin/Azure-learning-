using System.Windows;

namespace WebApiTester;

public partial class App : Application
{
}
