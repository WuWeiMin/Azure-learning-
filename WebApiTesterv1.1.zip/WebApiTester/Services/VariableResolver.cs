using System.Text.RegularExpressions;

namespace WebApiTester.Services;

public class VariableResolver
{
    private static readonly Regex VarPattern = new(@"\{\{(\w+)\}\}", RegexOptions.Compiled);

    // 把字符串中的 {{key}} 替换成 variables 字典里的值，找不到就原样保留
    public string Resolve(string input, IDictionary<string, string> variables)
    {
        if (string.IsNullOrEmpty(input)) return input;

        return VarPattern.Replace(input, match =>
        {
            var key = match.Groups[1].Value;
            return variables.TryGetValue(key, out var value) ? value : match.Value;
        });
    }
}
