# WebApiTester - 最小可运行的 API 测试工具骨架

## 如何使用
1. 解压后，在 VS2026 中选择「打开 -> 文件夹」，选中 `WebApiTester` 目录
   （或者直接双击 `WebApiTester.csproj` 用 VS 打开）。
2. VS 会自动还原 NuGet 包（`CommunityToolkit.Mvvm`）。
3. 按 F5 运行，默认会请求一个公开测试接口 `jsonplaceholder.typicode.com`，
   验证环境是否跑通。

## 当前已实现
- Method + URL 输入，Send 按钮发请求
- Headers 动态增删、可勾选启用/禁用
- Body（JSON/文本）编辑，自动设置 Content-Type
- 环境变量 `{{key}}` 替换（作用于 URL / Headers / Body）
- 响应区：状态码（带颜色）、耗时、Headers、格式化后的 JSON Body

## 项目结构
```
WebApiTester/
  Models/          请求头、响应结果等数据模型
  Services/        HttpRequestService（发请求）、VariableResolver（变量替换）
  ViewModels/       MainViewModel（MVVM 绑定与命令）
  MainWindow.xaml   主界面
```

## 后续可以扩展的方向（建议顺序）
1. **Collection 管理**：把请求保存成 JSON 文件，支持新建/加载/删除多个 Collection
2. **请求历史**：每次 Send 后记录一条历史，双击可以恢复请求
3. **多环境切换**：现在 Variables 只有一套，可以扩展成 Dev/Test/Prod 多个环境下拉切换
4. **认证模块**：加一个 Auth Tab，支持 Basic / Bearer Token，
   进阶可以用 `Microsoft.Identity.Client` 做 OAuth2
5. **JSON 语法高亮**：现在 Body/Response 用的是普通 TextBox，
   引入 `AvalonEdit`（NuGet: `AvalonEdit`）可以做到语法高亮和折叠，体验更接近 Postman
6. **Response 里跑测试脚本**：类似 Postman 的 Tests，
   可以用 `Microsoft.CodeAnalysis.CSharp.Scripting` 执行一段 C# 断言脚本

## 已知的简化点（先跑起来，后面再打磨）
- Body 只支持 JSON/纯文本，没做 form-data / multipart
- 没有做请求取消（长时间挂起的请求无法手动中断）
- 没有做 SSL 证书校验的自定义选项（比如允许自签名证书测内网 API）
